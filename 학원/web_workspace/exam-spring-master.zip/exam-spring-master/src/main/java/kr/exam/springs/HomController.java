package kr.exam.springs;

public class HomController {
}
